Test Repository
-----------------

Note: This repo doesn't actually _do_ anything, it's just for testing git-risk.

At some point in time, we should actually remove this repo, and replace it with
a dogfood version of git-risk. (i.e. run the tests on the git-risk repo itself).
