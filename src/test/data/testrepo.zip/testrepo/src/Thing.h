#ifndef __THING_H__
#define __THING_H__

#include <string>

class Thing {
  protected:
    std::string mName;

  public:
    Thing(std::string aName);
    ~Thing();

    virtual void printName();
};

#endif

