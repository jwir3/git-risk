#ifndef __THING_H__
#define __THING_H__

#include <string>

class Thing {
  private:
    std::string mName;

  public:
    Thing(std::string aName);
    ~Thing();


    void printName();
};

#endif

